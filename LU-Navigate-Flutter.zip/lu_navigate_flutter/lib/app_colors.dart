import 'package:flutter/material.dart';

abstract final class AppColors {
  static const primaryGreen = Color(0xFF005A36);
  static const lightGreen = Color(0xFFE6F4EA);
  static const background = Color(0xFFF9FAFB);
  static const darkText = Color(0xFF111827);
  static const secondaryText = Color(0xFF4B5563);
  static const mutedGray = Color(0xFF9CA3AF);
  static const iosGray = Color(0xFF8E8E93);
  static const orange = Color(0xFFD97706);
  static const red = Color(0xFFDC2626);
  static const blue = Color(0xFF0284C7);
}
