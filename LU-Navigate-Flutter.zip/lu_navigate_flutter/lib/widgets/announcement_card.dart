import 'package:flutter/material.dart';

import '../app_colors.dart';
import '../models/announcement.dart';

class AnnouncementCard extends StatelessWidget {
  const AnnouncementCard({
    super.key,
    required this.announcement,
    required this.isRead,
    required this.onTap,
    required this.onDismiss,
  });

  final Announcement announcement;
  final bool isRead;
  final VoidCallback onTap;
  final VoidCallback onDismiss;

  bool get _emergency => announcement.category == AnnouncementCategory.emergency;

  @override
  Widget build(BuildContext context) {
    final categoryColor = _emergency ? AppColors.red : AppColors.blue;
    return Opacity(
      opacity: isRead ? .70 : 1,
      child: Material(
        color: isRead ? const Color(0xFFF3F4F6) : (_emergency ? const Color(0xFFFFF5F5) : Colors.white),
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _emergency ? const Color(0xFFFECdd3) : const Color(0xFFE5E7EB)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(_emergency ? Icons.error : Icons.info, color: categoryColor, size: 14),
                    const SizedBox(width: 4),
                    Text(_emergency ? 'EMERGENCY ALERT' : 'CLASS UPDATE', style: TextStyle(color: categoryColor, fontSize: 11, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    if (!isRead) Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primaryGreen, shape: BoxShape.circle)),
                    if (!isRead) const SizedBox(width: 6),
                    Text(announcement.time, style: const TextStyle(fontSize: 11, color: AppColors.mutedGray)),
                    const SizedBox(width: 4),
                    IconButton(onPressed: onDismiss, icon: const Icon(Icons.close, size: 16, color: AppColors.mutedGray), visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(minHeight: 20, minWidth: 20), tooltip: 'Dismiss announcement'),
                  ],
                ),
                const SizedBox(height: 8),
                Text(announcement.title, style: TextStyle(fontSize: 15, fontWeight: isRead ? FontWeight.w500 : FontWeight.w700, color: isRead ? AppColors.secondaryText : AppColors.darkText)),
                const SizedBox(height: 4),
                Text(announcement.body, style: const TextStyle(fontSize: 13, color: AppColors.secondaryText, height: 1.38)),
                const SizedBox(height: 10),
                const Divider(height: 1, color: Color(0xFFF3F4F6)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: Text('Posted by: ${announcement.author}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF6B7280)))),
                    Text(isRead ? 'Mark as unread' : 'Tap to mark read', style: const TextStyle(fontSize: 10, fontStyle: FontStyle.italic, color: AppColors.mutedGray)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
