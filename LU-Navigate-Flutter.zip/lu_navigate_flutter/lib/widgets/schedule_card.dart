import 'package:flutter/material.dart';

import '../app_colors.dart';
import '../models/schedule_item.dart';

class ScheduleCard extends StatelessWidget {
  const ScheduleCard({super.key, required this.item});

  final ScheduleItem item;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: Text(item.subject!, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.darkText))),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: AppColors.lightGreen, borderRadius: BorderRadius.circular(6)),
                child: Text(item.section!, style: const TextStyle(color: AppColors.primaryGreen, fontSize: 11, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _DetailLine(icon: Icons.access_time_outlined, text: item.time),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.location_on_outlined, color: AppColors.secondaryText, size: 15),
              const SizedBox(width: 4),
              Expanded(child: Text(item.room == 'OL' ? 'Online Class' : 'Room: ${item.room}', style: const TextStyle(fontSize: 13, color: AppColors.secondaryText))),
              Icon(Icons.person_outline, color: AppColors.secondaryText, size: 15),
              const SizedBox(width: 4),
              Flexible(child: Text(item.instructor!, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: AppColors.secondaryText))),
            ],
          ),
        ],
      ),
    );
  }
}

class _DetailLine extends StatelessWidget {
  const _DetailLine({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Icon(icon, color: AppColors.secondaryText, size: 15),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 13, color: AppColors.secondaryText)),
        ],
      );
}
