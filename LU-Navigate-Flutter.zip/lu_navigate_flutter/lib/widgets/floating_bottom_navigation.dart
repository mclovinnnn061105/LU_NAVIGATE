import 'package:flutter/material.dart';

import '../app_colors.dart';

class FloatingBottomNavigation extends StatelessWidget {
  const FloatingBottomNavigation({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  final int currentIndex;
  final ValueChanged<int> onTap;

  static const _items = <_NavigationItem>[
    _NavigationItem('Map', Icons.map_outlined),
    _NavigationItem('Schedule', Icons.calendar_month_outlined),
    _NavigationItem('Announcements', Icons.campaign_outlined),
    _NavigationItem('Profile', Icons.person_outline),
  ];

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: 8,
      shadowColor: Colors.black.withValues(alpha: .12),
      borderRadius: BorderRadius.circular(32),
      child: SizedBox(
        height: 64,
        child: Row(
          children: List.generate(_items.length, (index) {
            final item = _items[index];
            final selected = currentIndex == index;
            final color = selected ? AppColors.primaryGreen : AppColors.iosGray;
            return Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(32),
                onTap: () => onTap(index),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.icon, color: color, size: 22),
                    const SizedBox(height: 2),
                    Text(
                      item.label,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _NavigationItem {
  const _NavigationItem(this.label, this.icon);

  final String label;
  final IconData icon;
}
