import 'package:flutter/material.dart';

import '../../app_colors.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _feedbackController = TextEditingController();
  bool _notificationsEnabled = true;
  bool _aboutExpanded = false;

  @override
  void dispose() {
    _feedbackController.dispose();
    super.dispose();
  }

  Future<void> _openFeedbackDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Send Feedback', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.darkText)),
              const SizedBox(height: 8),
              const Text('Found a bug or have a suggestion for the campus map or schedule? Let us know below.', style: TextStyle(fontSize: 13, height: 1.38, color: Color(0xFF6B7280))),
              const SizedBox(height: 16),
              TextField(
                controller: _feedbackController,
                minLines: 4,
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
                style: const TextStyle(fontSize: 13, color: AppColors.darkText),
                decoration: InputDecoration(
                  hintText: 'Type your message here...',
                  hintStyle: const TextStyle(color: AppColors.mutedGray),
                  filled: true,
                  fillColor: AppColors.background,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFE5E7EB))),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFFE5E7EB))),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: TextButton(onPressed: () => Navigator.pop(dialogContext), style: TextButton.styleFrom(backgroundColor: const Color(0xFFF3F4F6), foregroundColor: AppColors.secondaryText, padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w600)))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton(onPressed: () => _submitFeedback(dialogContext), style: FilledButton.styleFrom(backgroundColor: AppColors.primaryGreen, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Text('Submit', style: TextStyle(fontWeight: FontWeight.w700)))),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submitFeedback(BuildContext dialogContext) async {
    if (_feedbackController.text.trim().isEmpty) {
      await showDialog<void>(
        context: dialogContext,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: const Text('Please enter your feedback or issue description.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      return;
    }
    _feedbackController.clear();
    Navigator.pop(dialogContext);
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Thank You!'),
        content: const Text('Your feedback has been submitted to the IT support team.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  Future<void> _confirmLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Log Out'),
        content: const Text('Are you sure you want to sign out of your account?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), style: TextButton.styleFrom(foregroundColor: AppColors.red), child: const Text('Log Out')),
        ],
      ),
    );
    if (shouldLogout != true || !mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Signed Out'),
        content: const Text('You have been successfully logged out.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(child: _profileHeader()),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
            sliver: SliverToBoxAdapter(
              child: Column(
                children: [
                  _accountCard(),
                  const SizedBox(height: 14),
                  _supportCard(),
                  const SizedBox(height: 18),
                  _logoutButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _profileHeader() {
    return Container(
      color: AppColors.primaryGreen,
      padding: const EdgeInsets.fromLTRB(16, 28, 16, 28),
      child: const Column(
        children: [
          CircleAvatar(radius: 36, backgroundColor: Colors.white, child: CircleAvatar(radius: 33, backgroundColor: AppColors.orange, child: Text('AC', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700)))),
          SizedBox(height: 10),
          Text('Adriel Enzo Cabrera', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
          SizedBox(height: 2),
          Text('BSCS-DS • 3rd Year', style: TextStyle(color: AppColors.lightGreen, fontSize: 13)),
          SizedBox(height: 2),
          Text('Laguna University', style: TextStyle(color: Color(0xFFA7F3D0), fontSize: 11, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _accountCard() {
    return _SectionCard(
      title: 'Account Preferences',
      child: Column(
        children: [
          const _InfoRow(icon: Icons.credit_card_outlined, label: 'Student ID', value: '241-0882'),
          const _InfoRow(icon: Icons.school_outlined, label: 'Program', value: 'BS Computer Science'),
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(
              children: [
                const Icon(Icons.notifications_outlined, size: 18, color: AppColors.secondaryText),
                const SizedBox(width: 10),
                const Expanded(child: Text('Push Notifications', style: TextStyle(fontSize: 13, color: Color(0xFF374151)))),
                Switch(value: _notificationsEnabled, onChanged: (value) => setState(() => _notificationsEnabled = value), activeTrackColor: AppColors.primaryGreen, inactiveTrackColor: const Color(0xFFD1D1D6), thumbColor: const WidgetStatePropertyAll(Colors.white)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _supportCard() {
    return _SectionCard(
      title: 'Support & Feedback',
      child: Column(
        children: [
          _ActionRow(icon: Icons.chat_bubble_outline, label: 'Report Issue or Send Feedback', onTap: _openFeedbackDialog),
          _ActionRow(icon: Icons.info_outline, label: 'About Campus App', onTap: () => setState(() => _aboutExpanded = !_aboutExpanded), expanded: _aboutExpanded, last: _aboutExpanded),
          if (_aboutExpanded) _credits(),
        ],
      ),
    );
  }

  Widget _credits() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Laguna University Campus App', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF0F172A))),
          SizedBox(height: 2),
          Text('Meet the Developers!', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
          Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(height: 1, color: Color(0xFFE2E8F0))),
          Text('DEVELOPMENT TEAM', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .5, color: AppColors.primaryGreen)),
          SizedBox(height: 8),
          _CreditItem(role: 'Frontend', name: 'Adriel Enzo M. Cabrera'),
          _CreditItem(role: 'Backend', name: 'Mark Adrian G. Correa'),
          _CreditItem(role: 'Backend', name: 'Mark Angel E. Diaz'),
        ],
      ),
    );
  }

  Widget _logoutButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _confirmLogout,
        icon: const Icon(Icons.logout_outlined, size: 18),
        label: const Text('Log Out'),
        style: OutlinedButton.styleFrom(foregroundColor: AppColors.red, backgroundColor: const Color(0xFFFEF2F2), side: const BorderSide(color: Color(0xFFFECACA)), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)), textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE5E7EB))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 15, color: AppColors.darkText, fontWeight: FontWeight.w700)), const SizedBox(height: 12), child]),
      );
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFF3F4F6)))),
        child: Row(children: [Icon(icon, size: 18, color: AppColors.secondaryText), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF374151)))), Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.darkText))]),
      );
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({required this.icon, required this.label, required this.onTap, this.expanded = false, this.last = false});

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool expanded;
  final bool last;

  @override
  Widget build(BuildContext context) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: last ? null : const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFF3F4F6)))),
            child: Row(children: [Icon(icon, size: 18, color: AppColors.primaryGreen), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF374151), fontWeight: FontWeight.w500))), Icon(expanded ? Icons.keyboard_arrow_down : Icons.chevron_right, size: 18, color: AppColors.mutedGray)]),
          ),
        ),
      );
}

class _CreditItem extends StatelessWidget {
  const _CreditItem({required this.role, required this.name});

  final String role;
  final String name;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [Text(role, style: const TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.w500)), const Spacer(), Flexible(child: Text(name, textAlign: TextAlign.right, style: const TextStyle(fontSize: 12, color: Color(0xFF1E293B), fontWeight: FontWeight.w600)))]),
      );
}
