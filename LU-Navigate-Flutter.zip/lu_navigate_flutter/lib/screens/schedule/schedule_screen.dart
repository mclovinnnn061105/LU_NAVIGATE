import 'package:flutter/material.dart';

import '../../app_colors.dart';
import '../../data/schedule_data.dart';
import '../../models/schedule_item.dart';
import '../../widgets/schedule_card.dart';
import '../../widgets/vacant_schedule_card.dart';

class ScheduleScreen extends StatefulWidget {
  const ScheduleScreen({super.key});

  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  String _selectedDay = 'Mon';
  bool _syncDialogOpen = false;
  bool _isSyncing = false;

  Future<void> _syncSchedule() async {
    setState(() => _isSyncing = true);
    await Future<void>.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() {
      _isSyncing = false;
      _syncDialogOpen = false;
    });
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Registration Form Synchronized! 📄'),
        content: const Text('Successfully verified 18 units across all 6 official courses.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final schedule = weeklySchedule[_selectedDay] ?? const <ScheduleItem>[];
    return SafeArea(
      bottom: false,
      child: Stack(
        children: [
          CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _buildHeader()),
              SliverToBoxAdapter(child: _buildDayBar()),
              SliverToBoxAdapter(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: const BoxDecoration(color: Color(0xFFF3F4F6), border: Border(bottom: BorderSide(color: Color(0xFFE5E7EB)))),
                  child: Text.rich(TextSpan(text: 'Enrolled Schedule for ', style: const TextStyle(fontSize: 13, color: Color(0xFF374151)), children: [TextSpan(text: _selectedDay, style: const TextStyle(fontWeight: FontWeight.w700))])),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
                sliver: schedule.isEmpty
                    ? const SliverToBoxAdapter(child: _EmptySchedule())
                    : SliverList.builder(
                        itemCount: schedule.length,
                        itemBuilder: (context, index) {
                          final item = schedule[index];
                          return item.isVacant ? VacantScheduleCard(item: item) : ScheduleCard(item: item);
                        },
                      ),
              ),
            ],
          ),
          if (_syncDialogOpen) _SyncDialog(isSyncing: _isSyncing, onSync: _syncSchedule, onClose: _isSyncing ? null : () => setState(() => _syncDialogOpen = false)),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Academic Timetable', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.darkText)),
                SizedBox(height: 2),
                Text('Laguna University • BSCS-DS 3A', style: TextStyle(fontSize: 11, color: Color(0xFF6B7280))),
              ],
            ),
          ),
          FilledButton.icon(
            onPressed: () => setState(() => _syncDialogOpen = true),
            icon: const Icon(Icons.refresh_outlined, size: 16),
            label: const Text('Sync Form'),
            style: FilledButton.styleFrom(backgroundColor: AppColors.primaryGreen, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          ),
        ],
      ),
    );
  }

  Widget _buildDayBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: _days.map((day) {
          final selected = _selectedDay == day;
          return Expanded(
            child: Padding(
              padding: EdgeInsets.only(right: day == _days.last ? 0 : 8),
              child: Material(
                color: selected ? AppColors.primaryGreen : const Color(0xFFF3F4F6),
                borderRadius: BorderRadius.circular(8),
                child: InkWell(
                  onTap: () => setState(() => _selectedDay = day),
                  borderRadius: BorderRadius.circular(8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(day, textAlign: TextAlign.center, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: selected ? Colors.white : AppColors.secondaryText)),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _SyncDialog extends StatelessWidget {
  const _SyncDialog({required this.isSyncing, required this.onSync, required this.onClose});

  final bool isSyncing;
  final VoidCallback onSync;
  final VoidCallback? onClose;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black.withValues(alpha: .50),
        child: Center(
          child: Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Registration Form Synced', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.darkText)),
                    const SizedBox(height: 8),
                    const Text('Your official Laguna University Registration Form (Student No: 241-0882) is active and verified.', style: TextStyle(fontSize: 13, height: 1.38, color: Color(0xFF6B7280))),
                    const SizedBox(height: 16),
                    if (isSyncing)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Center(child: Column(children: [CircularProgressIndicator(color: AppColors.primaryGreen), SizedBox(height: 10), Text('Syncing official enrollment data...', style: TextStyle(fontSize: 13, color: AppColors.secondaryText, fontWeight: FontWeight.w600))])),
                      )
                    else
                      SizedBox(width: double.infinity, child: FilledButton(onPressed: onSync, style: FilledButton.styleFrom(backgroundColor: AppColors.primaryGreen, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Refresh Timetable', style: TextStyle(fontWeight: FontWeight.w700))))),
                    const SizedBox(height: 10),
                    SizedBox(width: double.infinity, child: TextButton(onPressed: onClose, style: TextButton.styleFrom(backgroundColor: const Color(0xFFF3F4F6), foregroundColor: AppColors.secondaryText, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('Close', style: TextStyle(fontWeight: FontWeight.w600))))),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptySchedule extends StatelessWidget {
  const _EmptySchedule();

  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Column(children: [Icon(Icons.calendar_month_outlined, size: 40, color: AppColors.mutedGray), SizedBox(height: 10), Text('No classes listed in your registration form for this day.', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: AppColors.mutedGray))]),
      );
}
