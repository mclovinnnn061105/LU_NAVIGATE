import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'screens/announcements/announcements_screen.dart';
import 'screens/map/map_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/schedule/schedule_screen.dart';
import 'widgets/floating_bottom_navigation.dart';

void main() => runApp(const LuNavigateApp());

class LuNavigateApp extends StatelessWidget {
  const LuNavigateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LU Navigate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primaryGreen, brightness: Brightness.light),
        fontFamily: 'Roboto',
      ),
      home: const MainNavigationShell(),
    );
  }
}

class MainNavigationShell extends StatefulWidget {
  const MainNavigationShell({super.key});

  @override
  State<MainNavigationShell> createState() => _MainNavigationShellState();
}

class _MainNavigationShellState extends State<MainNavigationShell> {
  int _currentIndex = 0;

  final _screens = const <Widget>[MapScreen(), ScheduleScreen(), AnnouncementsScreen(), ProfileScreen()];

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.paddingOf(context).bottom + 16;
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: IndexedStack(index: _currentIndex, children: _screens)),
          Positioned(
            left: 20,
            right: 20,
            bottom: bottom,
            child: FloatingBottomNavigation(currentIndex: _currentIndex, onTap: (index) => setState(() => _currentIndex = index)),
          ),
        ],
      ),
    );
  }
}
