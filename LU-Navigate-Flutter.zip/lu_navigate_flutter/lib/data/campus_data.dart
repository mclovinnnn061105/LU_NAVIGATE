import '../models/campus_location.dart';

const campusLocations = <CampusLocation>[
  CampusLocation(id: 'admin', label: 'Admin Bldg.', top: .30, left: .15, name: 'Admin Building', description: 'Houses the Registrar, Cashier, Accounting, and President\'s offices.', floorsCount: '3 Floors Available'),
  CampusLocation(id: 'covered', label: 'Covered Court', top: .32, left: .11, name: 'Covered Court', description: 'Main venue for sports and university events.', floorsCount: '1 Floor Available'),
  CampusLocation(id: 'athletevillage', label: "Athlete's Village", top: .43, left: .29, name: "Athlete's Village", description: 'Dormitories and facilities for student-athletes.', floorsCount: '2 Floors Available'),
  CampusLocation(id: 'oreta', label: 'Oreta Bldg.', top: .49, left: .27, name: 'Oreta Building', description: 'Classrooms and lecture halls.', floorsCount: '3 Floors Available'),
  CampusLocation(id: 'newbuilding', label: 'New Bldg.', top: .31, left: .20, name: 'New Building', description: 'Newly constructed wing for additional classes.', floorsCount: '4 Floors Available'),
  CampusLocation(id: 'warehouse', label: 'Warehouse', top: .44, left: .11, name: 'Warehouse', description: 'University storage facility.', floorsCount: '1 Floor Available'),
  CampusLocation(id: 'engineer', label: 'Engr. Bldg.', top: .45, left: .36, name: 'Engineering Building', description: 'Laboratories and offices for the Engineering department.', floorsCount: '3 Floors Available'),
  CampusLocation(id: 'mpg', label: 'Multi-Purpose Gym', top: .41, left: .40, name: 'Multi-Purpose Gym', description: 'Indoor courts and physical education space.', floorsCount: '2 Floors Available'),
  CampusLocation(id: 'gymnasium', label: 'Gymnasium', top: .51, left: .41, name: 'Gymnasium', description: 'Large arena for major sporting events.', floorsCount: '1 Floor Available'),
  CampusLocation(id: 'canteen', label: 'Canteen', top: .58, left: .41, name: 'Canteen', description: 'Food stalls and dining area for students.', floorsCount: '1 Floor Available'),
  CampusLocation(id: 'lurooms', label: 'LU Rooms', top: .66, left: .44, name: 'LU Rooms', description: 'Additional academic rooms and function spaces.', floorsCount: '2 Floors Available'),
];
